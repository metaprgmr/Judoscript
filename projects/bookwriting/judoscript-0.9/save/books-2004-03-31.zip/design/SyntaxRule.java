import java.io.*;
import java.util.ArrayList;

public class SyntaxRule
{
  public static final int ATTR_NT = 0;
  public static final int ATTR_T = 1;
  public static final int ATTR_SYNTAX = 2;
  public static final int ATTR_NL = 3;
  public static final int ATTR_SP = 4;

  private static boolean escapeSgml = false;

  String name;
  ArrayList components = new ArrayList();

  public String getName() { return name; }
  public ArrayList getComponents() { return components; }

  private static StringBuffer sb = new StringBuffer();
  private static SyntaxRule ret;

  private static void checkNT() {
    String n = sb.toString().trim();
    sb.setLength(0);
    if (n.equals("")) return;

    int attr = ATTR_T;
    for (int i=n.length()-1; i>=0; --i) {
      char ch = n.charAt(i);
      if (Character.isLetter(ch) && !Character.isUpperCase(ch)) {
        attr = ATTR_NT;
        break;
      }
    }
    ret.components.add(new AttributedName(attr, n, escapeSgml));
  }

  public static SyntaxRule parse(String text, boolean escape_sgml) {
    escapeSgml = escape_sgml;
    int i = text.indexOf(':');
    if (i < 0) {
      System.out.println("No ':' ==> " + text);
      return null;
    }
    ret = new SyntaxRule();
    ret.name = text.substring(0,i).trim();

    text = text.substring(i+1).trim();
    for (i=0; i < text.length(); ++i) {
      char ch = text.charAt(i);
      switch(ch) {
      case '\r': break; // eat it.
      case '\n': checkNT(); ret.components.add(nl); break;
      case '~':  checkNT(); ret.components.add(sp); break;
      case '|':  checkNT(); ret.components.add(or); break;
      case '[':  checkNT(); ret.components.add(left_bracket); break;
      case ']':  checkNT(); ret.components.add(right_bracket); break;
      case '(':  checkNT(); ret.components.add(left_paren); break;
      case ')':  checkNT();
                 ch = (i == text.length()-1) ? 0 : text.charAt(++i);
                 switch(ch) {
                 case '?': ret.components.add(right_0_1); break;
                 case '*': ret.components.add(right_0_more); break;
                 case '+': ret.components.add(right_1_more); break;
                 case ',': switch(text.charAt(++i)) {
                           case '*': ret.components.add(comma_0_more); break;
                           case '+': ret.components.add(comma_1_more); break;
                           default: --i;
                           }
                           break;
                 default:  ret.components.add(right_paren);
                           if (ch != 0) --i;
                 }
                 break;
      case '"':  checkNT();
                 int start = ++i;
                 i = text.indexOf('"', start);
                 if (i < 0) {
                   System.out.println("No matching '\"' ==> " + text);
                   return null;
                 }
                 ret.components.add(new AttributedName(ATTR_T, text.substring(start,i), escapeSgml));
                 break;
      default:   sb.append((char)ch);
      }
    }
    checkNT();
    return ret;
  }

  public static class AttributedName
  {
    int attr;
    String name;

    AttributedName(int a, String n, boolean escapeSgml) {
      attr = a;
      name = escapeSgml ? org.apache.commons.lang.StringEscapeUtils.escapeHtml(n) : n;
    }

    public String toString() { return name; }
    public int getAttr() { return attr; }
  }

  static final AttributedName nl = new AttributedName(ATTR_NL,null,false);
  static final AttributedName sp = new AttributedName(ATTR_SP,null,false);
  static final AttributedName left_bracket = new AttributedName(ATTR_SYNTAX, "[", false);
  static final AttributedName right_bracket = new AttributedName(ATTR_SYNTAX, "]", false);
  static final AttributedName left_paren = new AttributedName(ATTR_SYNTAX, "(", false);
  static final AttributedName right_paren = new AttributedName(ATTR_SYNTAX, ")", false);
  static final AttributedName right_0_1 = new AttributedName(ATTR_SYNTAX, ")?", false);
  static final AttributedName right_0_more = new AttributedName(ATTR_SYNTAX, ")*", false);
  static final AttributedName right_1_more = new AttributedName(ATTR_SYNTAX, ")+", false);
  static final AttributedName comma_0_more = new AttributedName(ATTR_SYNTAX, "),*", false);
  static final AttributedName comma_1_more = new AttributedName(ATTR_SYNTAX, "),+", false);
  static final AttributedName or = new AttributedName(ATTR_SYNTAX, "|", false);
}
