// Used by fromPaMa.judo

public interface Mama
{
  void singSong();
  int height();
}
