public class Foo
{
  public String bar(byte x) { return "byte"; }
  public String bar(char x) { return "char"; }
  public String bar(Integer x) { return "Integer"; }
  public String bar(java.util.Date x) { return "Date"; }
}

