public class Foo2
{
  public static class Bar {
  }
}

