This is the complete collection of test cases/examples.
Some of them are used in the automated testing process.
Others are interactive and must be run manually.

Many programs herein are referenced in the book;
the listings in the book may be simplified a little.

These test cases are grouped into five groups:

  1.lang -- the basic language programming including Java scripting.

  2.ess  -- the essential supported services.

  3.app  -- the functional domain support.

  4.adv  -- advanced topics.

  5.util -- practical programs.
