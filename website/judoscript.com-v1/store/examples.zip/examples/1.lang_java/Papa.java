// used by fromPaMa.judo

public interface Papa
{
  void playBall();
  int height();
}
